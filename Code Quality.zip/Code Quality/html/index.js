
function evaluateInput(){        //checks the imput box

    

    //if(document.getElementById(dec).checked==false);
    /////number mode

    var s=document.getElementById("data").value;

    if(s.trim()=='')       //if input is empty
        document.getElementById("result").innerHTML="Field cannot be empty";            //p tag in body
    else if(!isNaN(s))      //a number
        displayNumber(s);
    else        //string
        displayName(s);
}
function displayNumber(s){
    var arr=["is invalid.","is less than 50.","is between 50 and 100", "is greater than 100."];
        if(s<0 || s>1000)
            document.getElementById("result").innerHTML="The number" + arr[0];  //0 to 1000
        else if(s<50)
            document.getElementById("result").innerHTML="The number" + arr[1];
        else if(s>=50 && s<=100)
            document.getElementById("result").innerHTML="The number "+ arr[2];
        else
            document.getElementById("result").innerHTML="The number" + arr[3];
}
function displayName(s){
    document.getElementById("result").innerHTML="The string entered was "+ s;
}
function evaluateInput2(){
 
        if(document.getElementById("dec").checked==false)
        {
            var y = document.getElementById("myDIV2");
            if (y.style.display === "none") {
             y.style.display = "block";
            } else {
             y.style.display = "none";
            }
        }
        var x = document.getElementById("myDIV");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
}
function evaluateInput3(){
    
    var n=document.getElementById("name").value;
    if(document.getElementById("male").checked==true)
    var gen="male";
    else
    var gen="Female";
    document.getElementById("abc").innerHTML="Your name is "+n+ " and you are a "+ gen;
}
function start(){
if(document.getElementById("dec").checked==true)
document.getElementById("myDIV2").style.display = "none";
}