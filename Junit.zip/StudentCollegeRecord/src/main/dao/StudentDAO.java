package dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import model.Student;

public class StudentDAO {

	private  Map<Integer,Student> studentList;
	static {
		
	}
	@SuppressWarnings("deprecation")
	public StudentDAO() {
		// TODO Auto-generated constructor stub
		studentList=new HashMap<Integer,Student>();
		studentList.put(1,new Student(1, "Anushree", "Rai", "Lucknow", new Date(1997, 01, 27), 12345, 3, "cse"));
		studentList.put(2,new Student(2, "Divyansh", "Srivastava", "Mumbai", new Date(1996, 05, 15), 12876, 4, "ec"));
		studentList.put(3,new Student(3, "Aubhav", "Gupta", "Bhopal", new Date(1992, 9, 2), 12509, 5, "mech"));
		studentList.put(4,new Student(4, "Dheeraj", "Agrawal", "Pune", new Date(1994, 4, 11), 12325, 7, "civil"));
		studentList.put(5,new Student(5, "Yash", "Gupta", "Jabalpur", new Date(1994, 3, 26), 45321, 8, "cse"));
	}

	public Student addStudent(Student student) {
		
		if(studentList.get(student.getRollNo())!=null)
		return null;
		studentList.put(student.getRollNo(), student);
		return studentList.get(student.getRollNo());
	}

	public Student updateStudent(Student student) {
		
		if(studentList.get(student.getRollNo())==null)
			return null;
		studentList.put(student.getRollNo(), student);	
		
		return studentList.get(student.getRollNo());

	}

	public Student getStudent(int rollNo) {
		
		if(studentList.get(rollNo)==null)
			return null;
			
		
		return studentList.get(rollNo);
	}

	

	public Student deleteStudent(int rollNo) {
		
		if(studentList.get(rollNo)==null)
			return null;
		Student stud=studentList.remove(rollNo);
		return stud;
	}

}
