package com.anushree.soapAssignment;

import javax.xml.ws.Endpoint;

public class SoapPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8080/WS/com.anushree.soapAssignment", new soapImp());
		
	}
}