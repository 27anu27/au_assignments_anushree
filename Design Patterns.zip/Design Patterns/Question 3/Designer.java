package com.anushree.question3;

public abstract class Designer {

	public final void buildHouse()
	{
		DesignStructure();
	    DesignWalls();
	    DesignDoors();
	    DesignWindows();
	    DesignFurnishing();
		System.out.println("House is fully built");
	}

	private void DesignStructure() 
	{
		System.out.println("House Structure designed");
	}

	private void DesignWindows() 
	{
		System.out.println("Windows built");
	}	

	private void DesignDoors() 
	{
		System.out.println("Doors built");
	}

	private void DesignFurnishing() 
	{
		System.out.println("Furnishings designed");
	}

	public abstract void DesignWalls();
		
}