package com.anushree.question3;

public class DesignerPro 
{
	public static void main(String[] args) 
	{	
		Designer type = new MetalHouse();
		System.out.println("This is a Metal House");
		type.buildHouse();
		
		
		type = new GlassHouse();
		System.out.println("\n\nThis is a Glass House");
		type.buildHouse();
	}

}
