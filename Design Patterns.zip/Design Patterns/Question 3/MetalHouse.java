package com.anushree.question3;

public class MetalHouse extends Designer 
	{
	@Override
	public void DesignWalls() {
		System.out.println("Metal Walls built");
	}


}
