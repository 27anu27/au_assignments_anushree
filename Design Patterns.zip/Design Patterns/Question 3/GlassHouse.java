package com.anushree.question3;

public class GlassHouse extends Designer 
{
	@Override
	public void DesignWalls() 
	{
		System.out.println("Glass walls built");
	}


}
