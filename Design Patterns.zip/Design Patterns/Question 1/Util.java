package com.anushree.question1;

public interface Util {
	public void Log(String str);
}
