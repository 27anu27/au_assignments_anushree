package com.anushree.question2;
public class BatSecond implements Bat
	{
	@Override
	public void createBat() {
		System.out.println("Second Bat is produced");
	}

}
