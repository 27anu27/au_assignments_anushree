package com.anushree.question2;

public interface Bat 
{
	public abstract void createBat();
}
