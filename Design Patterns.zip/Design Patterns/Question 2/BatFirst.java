package com.anushree.question2;

public class BatFirst implements Bat {
	@Override
	public void createBat() {
		System.out.println("First Bat is produced");
	}

}
