package com.anushree.question2;

public interface Ball
{
	public abstract void createBall();
}
