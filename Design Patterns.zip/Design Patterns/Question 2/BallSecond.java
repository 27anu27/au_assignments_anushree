package com.anushree.question2;

public class BallSecond implements Ball
	{
	@Override
	public void createBall() {
		System.out.println("Second Ball is produced");
	}

}
