package com.anushree.question2;

public class BallFirst implements Ball
	{

	@Override
	public void createBall() {
		System.out.println("First Ball is produced");
	}

}
