package com.anushree.question2;

public interface Factory {
	 public abstract Bat createBat();
	 public abstract Ball createBall();

}
