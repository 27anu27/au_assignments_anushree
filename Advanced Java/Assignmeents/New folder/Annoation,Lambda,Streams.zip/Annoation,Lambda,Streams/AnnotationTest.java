package test;



@interface Student{
	int rollno();
	String name();
}



public class AnnotationTest {
	public static void main(String args[]) {
	}
	@Student(rollno=11,name="Anushree")
	public String toString() {
		return "Overriden toString method";
	}

}
