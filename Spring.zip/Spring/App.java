package com.anushree.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main( String[] args ){
        
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
      
        EmployeeDao dao=(EmployeeDao)context.getBean("edao");  
        
        List<Employee> list=dao.getAllEmployeesRowMapper();  
        for(Employee e:list)  
            System.out.println(e.getName()); 
        
        List<Employee> eList = new ArrayList<Employee>();
        Employee e1= new Employee(1,"Anushree",32000);
        Employee e2= new Employee(2,"Rai",45000);
        Employee e3= new Employee(3,"Shrey",45000);
        Employee e4= new Employee(4,"Pasari",35000);
        Employee e5= new Employee(5,"Rahul",32000);
        Employee e6= new Employee(6,"Pareek",38000);
        Employee e7= new Employee(7,"Chitrarth",40000);
        Employee e8= new Employee(8,"Tomar",27000);
        Employee e9= new Employee(9,"Divyansh",60000);
        Employee e10= new Employee(10,"Srivastava",30000);
        
        eList.add(e1);
        eList.add(e2);
        eList.add(e3);
        eList.add(e4);
        eList.add(e5);
        eList.add(e6);
        eList.add(e7);
        eList.add(e8);
        eList.add(e3);
        eList.add(e9);
        eList.add(e10);
        
        dao.insertBatch(eList);
        
        
    }
}
